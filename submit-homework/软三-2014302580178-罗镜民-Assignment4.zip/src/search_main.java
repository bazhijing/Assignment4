import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class search_main {
	private String search_words[];

	public void set_search_words(String words) {
		search_words = words.split(" |,");
		delete_empty();
	}

	public String search() {
//		for (int i = 0; i < search_words.length; i++)
//			System.out.println(search_words[i]);
		data data = new data();
		return output(data.sort(getTFs(data)),data);

	}

	private void delete_empty() {
		int length = search_words.length;
		String stopwords[] = new String[819];
		try {
			Scanner in = new Scanner(new File("stopwords.txt"));
			int i = 0;
			while (in.hasNextLine()) {
				stopwords[i] = in.nextLine();
				i++;
			}
			in.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		for (int i = 0; i < length; i++) {
			for (int j = 0; j < 819; j++) {
				if (search_words[i].equals(stopwords[j])) {
					search_words[i] = "";
				}
			}
		}
	}

	private int[] getTFs(data data) {
		int pro_number = data.get_pro_number();
		int TFs[] = new int[pro_number];
		for (int i = 0; i < pro_number; i++) {
			TFs[i] = 0;
			String name[][] = data.get_name();
			String edu[][] = data.get_edu();
			String majar[][] = data.get_major();
			String email[][] = data.get_email();
			String phone[][] = data.get_phone();
			for (int j = 0; j < search_words.length; j++) {
				if (search_words[j].equals(name[i][0]) || search_words[j].equals(name[i][1]))
					TFs[i] += 2;
				for (int k = 0; k < (edu[i]).length; k++) {
					if (search_words[j].equals(edu[i][k]))
						TFs[i]++;
				}
				for (int k = 0; k < (majar[i]).length; k++) {
					if (search_words[j].equals(majar[i][k]))
						TFs[i]++;
				}
				if (search_words[j].equals(email[i][0]) || search_words[j].equals(email[i][1]))
					TFs[i] += 2;
				if (search_words[j].equals(phone[i][0]) || search_words[j].equals(phone[i][1])
						|| search_words[j].equals(phone[i][2]))
					TFs[i] += 2;
				// the plus number double for similar function as quanzhong
				
			}
//			System.out.println(i + " "+TFs[i]);
		}
		return TFs;
	}
	
	private String output(int[]order ,data data){
		String output="";
		String name[] = data.get_names();
		String edu[] = data.get_edus();
		String majar[] = data.get_majors();
		String email[] = data.get_emails();
		String phone[] = data.get_phones();
		for(int i=0;i<data.get_pro_number();i++){
			output +=name[order[i]]+"\n"
					+edu[order[i]]+"\n"
					+majar[order[i]]+"\n"
					+email[order[i]]+"\n"
					+phone[order[i]]+"\n"+"\n";
		}
		return output;
	}
}