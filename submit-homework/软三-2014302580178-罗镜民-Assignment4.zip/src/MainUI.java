
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainUI frame = new MainUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainUI() {
		setTitle("ming de search");
		//to be clean code  this function should split into small one..but...
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 461, 398);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(6, 36, 324, 37);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JTextPane textPane = new JTextPane();
		textPane.setEditable(false);
		JScrollPane txrPane = new JScrollPane(textPane);
		txrPane.setBounds(18, 124, 428, 234);
		contentPane.add(txrPane);
		
		
		
		JLabel lblSearch = new JLabel("search the professor info");
		lblSearch.setBounds(17, 6, 169, 29);
		contentPane.add(lblSearch);
		
		JButton btnNewButton = new JButton("search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String search_words = textField.getText(); 
				if(search_words.equals("")){
					//we can show diag but..time...
					textPane.setText("please enter sth");
				}
				else{
					//we can new data object here,change to pass the data object into the search to reduce the use of mysql
					//but ....time...
					search_main search = new search_main();
					search.set_search_words(search_words);
					String search_result = search.search();
					textPane.setText(search_result);
					textPane.setCaretPosition(0);
				
				}
				
			}
		});
		btnNewButton.setBounds(329, 41, 117, 29);
		contentPane.add(btnNewButton);
		
		JLabel lblResultOutput = new JLabel("result output ");
		lblResultOutput.setBounds(16, 85, 96, 27);
		contentPane.add(lblResultOutput);
	}
}
