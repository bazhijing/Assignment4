
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;


public class data {
	private String name[][];
	private String org_name[];
	private String edu[][];
	private String org_edu[];
	private String majar[][];
	private String org_majar[];
	private String email[][];
	private String org_email[];
	private String phone[][];
	private String org_phone[];
	private ResultSet rs;
	private int professor_num = 26;
	private int order[];
	String mysqlurl;
	java.sql.Connection con = null;

	data() {
		mysqlurl = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		try {
			con = DriverManager.getConnection(mysqlurl);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		try {
			// 加载MySql的驱动类
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("找不到驱动程序类 ，加载驱动失败！");
			e.printStackTrace();
		}
		String sql = "select * from 2014302580178_professor_info";
		PreparedStatement sttm;
		try {
			sttm = (PreparedStatement) con.prepareStatement(sql);
			rs = sttm.executeQuery(sql);
			int i = 0;
			name = new String[professor_num][2];
			edu = new String[professor_num][];
			majar = new String[professor_num][];
			email = new String[professor_num][2];
			phone = new String[professor_num][3];
			org_edu = new String[professor_num];
			org_email = new String[professor_num];
			org_majar = new String[professor_num];
			org_name = new String[professor_num];
			org_phone = new String[professor_num];
			while (rs.next()) {
				org_name[i] = rs.getString(1);
				name[i] = rs.getString(1).split(" ");
				org_edu[i] = rs.getString(2);
				edu[i] = rs.getString(2).split(",| ");
				org_majar[i] = rs.getString(3);
				String temp[] = rs.getString(3).split("\n");
				String temp2="";
				for(int j=0;j<temp.length;j++){
					temp2 = temp2+" "+temp[j];
				}
				majar[i] = temp2.split(" ");
				org_email[i] = rs.getString(4);
				email[i][0] = rs.getString(4).split("@")[0];
				email[i][1] = rs.getString(4);
				org_phone[i] = rs.getString(5);
				phone[i][0] = rs.getString(5);
				temp = rs.getString(5).split("-");
				phone[i][1] = temp[1] + temp[2] + temp[3];
				phone[i][2] = temp[1] + "-" + temp[2] + "-" + temp[3];
				i++;
			}

			sttm.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// init data

	}

	public String[][] get_name() {
		return name;
	}

	public String[][] get_edu() {
		return edu;
	}

	public String[][] get_major() {
		return majar;
	}

	public String[][] get_email() {
		return email;
	}

	public String[][] get_phone() {
		return phone;
	}
	
	public String[] get_names() {
		return org_name;
	}

	public String[] get_edus() {
		return org_edu;
	}

	public String[] get_majors() {
		return org_majar;
	}

	public String[] get_emails() {
		return org_email;
	}

	public String[] get_phones() {
		return org_phone;
	}

	public int get_pro_number() {
		return professor_num;
	}
	public int[] sort(int[] TFs) {
		order = new int[professor_num];
		for (int i = 0; i < professor_num; i++) {
			order[i] = i;

		}
		int temp,temp2;
		for (int i = 0; i < professor_num; i++) {
			for (int j = i; j > 0; j--) {
				if (TFs[j] > TFs[j - 1]) {
					temp = order[j - 1];
					temp2 = TFs[j-1];
					order[j - 1] = order[j];
					TFs[j-1] = TFs[j];
					order[j] = temp;
					TFs[j] = temp2;
//					System.out.println(j+" huan "+(j-1));
				}
				else{
					break;
				}
			}
		}
//		for (int i = 0; i < professor_num; i++) {
//			System.out.println("order:" +order[i]);
//
//		}
		return order;
	}
}
